/*
 * GccApplication1.c
 *
 * Created: 2019-08-28 오후 12:13:16
 * Author : CDSL
 */ 

#include "mcu_init.h"
#include "dataType.h"


//////////////////////////////////////////////////////////////////////////////////////////////////////////////
volatile double g_dCurPos;	// 0~360
volatile double g_dCurVel;	//
volatile double g_dCurCur; // 측정 전류
volatile double g_dCurPos_before = 0;


/////////////////////////////////////
// Velocity Parameter
/////////////////////////////////////
volatile double dError_Vel;
volatile double dError_Vel_Sum;
volatile double dResult_I;
volatile double dKp_v = 8;				//8, 0.05
volatile double dKi_v = 0.05;

///////////////////////////////////////////////////
// Position Parameter
///////////////////////////////////////////////////
volatile double g_dError_Pos;
volatile double g_dDError_Pos;
volatile double g_dError_Pos_before;
volatile double dt = 0.0005;
volatile double g_dResult_w;
volatile double g_dKp_p = 11.0;
volatile double g_dKd_p = 5.;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////



enum{
	CURRENT_CONTROL = 0x01,
	VELOCITY_CONTROL = 0x02,
	POSITION_CONTROL = 0x04
};


volatile int32_t g_Cnt, g_preCnt;

volatile int g_SendFlag = 0;

volatile double g_Pdes;
volatile double g_Vlimit = 1.;
volatile double g_Climit = 1.;

volatile Packet_t g_PacketBuffer;
volatile unsigned char g_PacketMode;
volatile unsigned char g_ID = 1;
volatile unsigned char checkSize;

volatile unsigned char g_buf[256],g_BufWriteCnt,g_BufReadCnt;



void SetDutyCW(double v){
	
	while(TCNT1  == 0);

	int ocr = v * (400. / 24.) + 400;
	
	if(ocr > OCR_MAX)	ocr = OCR_MAX;
	else if(ocr < OCR_MIN)	ocr = OCR_MIN;
	OCR1A = OCR1B = ocr;
//*/
/*
	int ocr = v * (800. / 24.);
	
	if(ocr > OCR_MAX)	ocr = OCR_MAX;
	else if(ocr < -OCR_MAX)	ocr = -OCR_MAX;
	
	if(ocr < 0){
		OCR1A = 0;		
		OCR1B = -ocr;
	}
	else{
		OCR1B = 0;
		OCR1A = ocr;
	}
//*/

}


void InitLS7366(){
	
	PORTB = 0x00;
	SPI_MasterSend(SELECT_MDR0 | WR_REG);
	SPI_MasterSend(X4_QUAD | FREE_RUN | DISABLE_INDEX | SYNCHRONOUS_INDEX |FILTER_CDF_1);
	PORTB = 0x01;
	
	PORTB = 0x00;
	SPI_MasterSend(SELECT_MDR1 | WR_REG);
	SPI_MasterSend(FOUR_BYTE_COUNT_MODE | ENABLE_COUNTING);
	PORTB = 0x01;
	
	PORTB = 0x00;
	SPI_MasterSend(SELECT_CNTR | CLR_REG);
	PORTB = 0x01;
}



ISR(USART0_RX_vect){
	g_buf[g_BufWriteCnt++] = UDR0;

}




ISR(TIMER3_OVF_vect){
			
	TCNT3 = 65536 - 125;
			
	//Read LS7366
	int32_t cnt;
	
	PORTB = 0x00;
	SPI_MasterSend(SELECT_OTR | LOAD_REG);
	PORTB = 0x01;
			
	PORTB = 0x00;
	SPI_MasterSend(SELECT_OTR | RD_REG);
	cnt = SPI_MasterRecv();		cnt = cnt<< 8;
	cnt |= SPI_MasterRecv();	cnt = cnt<< 8;
	cnt |= SPI_MasterRecv();	cnt = cnt<< 8;
	cnt |= SPI_MasterRecv();
	PORTB = 0x01;
	g_Cnt = -cnt;

	/////////////////////////////////////////
	//모터상태 가져오기
	/////////////////////////////////////////
	g_dCurPos = g_Cnt*2.0*PI/((GEAR_RATIO)*CPT*ENCODER_RATE);	// 0~2pi
	g_dCurVel = (g_dCurPos - g_dCurPos_before) * 2000.; // RAD/SEC;
	g_dCurCur = 5.*GetADC(0)/1023. - 2.5; // 측정 전류
	g_dCurPos_before = g_dCurPos;
	
	
	//////////////////////////////////////////////////////////////////////////
	// Position Controller
	//////////////////////////////////////////////////////////////////////////
	g_dError_Pos = (g_Pdes - g_dCurPos);	//g_Pdes : RAD
	g_dDError_Pos = (g_dError_Pos - g_dError_Pos_before)/dt;
	g_dError_Pos_before = g_dError_Pos;
	g_dResult_w = g_dKp_p*g_dError_Pos + g_dKd_p*g_dDError_Pos;
	
	if(g_dResult_w >= MAX_VOLT){
		g_dResult_w = MAX_VOLT;
	}
	else if(g_dResult_w <= -MAX_VOLT){
		g_dResult_w = -MAX_VOLT;
	}
	g_Vlimit = g_dResult_w;
	SetDutyCW(g_dResult_w);
	
	
	if( g_Pdes * RAD2DEG > 100)
	{
		PORTA = 0xff;
		
	}else if(g_Pdes * RAD2DEG < 100)
	{
		PORTA = 0x00;
		
	}
	
	/*
	//////////////////////////////////////////////////////////////////////////
	// Velocity Controller
	//////////////////////////////////////////////////////////////////////////
	dError_Vel = (36. * DEG2RAD - g_dCurVel) ;
	dError_Vel_Sum += dError_Vel;// - 1/dKp_i*Anti_Wind_Vel;
	dResult_I = dKp_v*dError_Vel  + dKi_v*dError_Vel_Sum;
	
	if ( dResult_I > MAX_VOLT )
	{
		//Anti_Wind_Vel = dResult_I - 10.;
		dResult_I = MAX_VOLT;
	}
	else if( dResult_I < -MAX_VOLT)
	{
		//Anti_Wind_Vel = dResult_I + 10.;
		dResult_I = -MAX_VOLT;
	}
	g_Climit = dResult_I;
	SetDutyCW(dResult_I);
	*/
	//SetDutyCW(3);
	
	
	
	g_SendFlag++;

}



int main(void){

	Packet_t packet;
	packet.data.header[0] = packet.data.header[1] = packet.data.header[2] = packet.data.header[3] = 0xFE;

	
	InitIO();
	
	//Uart
	InitUart0();
	InitUart1();

	//SPI
	InitSPI();
	
	//Timer
	InitTimer1();
	InitTimer3();

	
	OCR1A = 0;      //1 L
	OCR1B = 0;      //2 L

	TCNT1 = 0;
	
	//ADC
	InitADC();
	
	//LS7366
	InitLS7366();
	
	TCNT3 = 65536 - 125;
	sei();

	unsigned char check = 0;
	
	while (1) {

		//수신된 데이터 처리
		for(;g_BufReadCnt != g_BufWriteCnt; g_BufReadCnt++){
			switch(g_PacketMode){
				case 0:
				
				if(g_buf[g_BufReadCnt] == 0xFF){
					checkSize++;
					if(checkSize == 4){
						g_PacketMode = 1;
					}
				}
				else{
					checkSize = 0;
				}
				break;
				
				case 1:
				g_PacketBuffer.buffer[checkSize++] = g_buf[g_BufReadCnt];

				if(checkSize == 8){
					if(g_PacketBuffer.data.id == g_ID){
						g_PacketMode = 2;
					}
					else{
						g_PacketMode = 0;
						checkSize = 0;
					}
				}
				break;

				case 2:
				g_PacketBuffer.buffer[checkSize++] = g_buf[g_BufReadCnt];
				check += g_buf[g_BufReadCnt];

				if(checkSize == g_PacketBuffer.data.size){
					if(check == g_PacketBuffer.data.check){
						switch(g_PacketBuffer.data.mode){
							case 2:
							g_Pdes = g_PacketBuffer.data.pos / 1000.;
							g_Vlimit = g_PacketBuffer.data.velo / 1000.;
							g_Climit = g_PacketBuffer.data.cur / 1000.;

							//saving target value to use

							break;
						}
					}
					check = 0;
					g_PacketMode = 0;
					checkSize = 0;
				}
				else if(checkSize > g_PacketBuffer.data.size || checkSize > sizeof(Packet_t)){
					check = 0;
					g_PacketMode = 0;
					checkSize = 0;
				}
			}
		}
		//data MFC로 보내는 코드
		if(g_SendFlag > 19){
			g_SendFlag = 0;
			packet.data.id = g_ID;
			packet.data.size = sizeof(Packet_data_t);
			packet.data.mode = 3;
			packet.data.check = 0;

			//현재 위치와 속도, 전류 값
			packet.data.pos = g_dCurPos * 1000.0;
			packet.data.velo = g_dCurVel * 1000.0;
			packet.data.cur = g_dCurCur * 1000.0;

			for(int i = 8; i < sizeof(Packet_t); i++){
				packet.data.check += packet.buffer[i];
			}

			for(int i=0; i<packet.data.size; i++){
				TransUart0(packet.buffer[i]);
			}
		}
	}
	
}

